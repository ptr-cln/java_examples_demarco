package org.trifari.ebookshop.enumerations;

public enum DatabaseEnum {

	MySQL,
	ORACLE,
	SQLServer;
	
}
